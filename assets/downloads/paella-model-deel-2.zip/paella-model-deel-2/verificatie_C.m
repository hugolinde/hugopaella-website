% VERIFICATIE_C  Rekent de code van fase 2 goed?
% 1) Verdamping uit: dan blijft zuivere warmtegeleiding over. Zolang de warmte de bovenkant
%    nog niet bereikt, geldt de exacte oplossing voor een half-oneindige laag die aan de
%    onderkant een constante warmtestroom q krijgt (Carslaw & Jaeger):
%      T(y,t) = T0 + (2q/k) [ sqrt(a t/pi) exp(-y^2/(4 a t)) - (y/2) erfc(y/(2 sqrt(a t))) ]
% 2) Roosterconvergentie met verdamping aan (t150, t200).
% 3) Energiebalans met verdamping aan.
P = params_paella(); q = P.P_netto_max/P.A_bodem; rho = 0.25;
fid = fopen('verificatie_C.csv','w'); fprintf(fid,'test,dy_mm,waarde1,waarde2\n');
% (1) exact zonder verdamping
for dy = [0.5 0.25 0.125 0.0625]*1e-3
  R = modelC_enthalpie(rho, q, P, 30, dy, [], false);
  a = R.k0/R.C0; H = R.hist;
  Tex = 100 + 2*q/R.k0*sqrt(a*H(:,1)/pi);
  sel = H(:,1) >= 1;
  err = max(abs(H(sel,2) - Tex(sel)));
  fprintf(fid,'exact,%g,%g,%g\n', dy*1e3, err, NaN);
  printf('zonder verdamping, dy=%.4f mm: grootste fout bodemtemperatuur = %.3f C\n', dy*1e3, err);
end
R = modelC_enthalpie(rho, q, P, 60, 0.0625e-3, [10 30], false); a = R.k0/R.C0;
H = R.hist; Tex = 100 + 2*q/R.k0*sqrt(a*H(:,1)/pi);
dlmwrite('fig_verif_tijd.csv', [H(:,1) H(:,2) Tex], 'precision', 6);
y = R.yc; prof = y*1e3;
for k = 1:2
  t = [10 30](k);
  ex = 100 + 2*q/R.k0*(sqrt(a*t/pi)*exp(-y.^2/(4*a*t)) - y/2.*erfc(y/(2*sqrt(a*t))));
  prof = [prof R.SnapT(:,k) ex];
end
dlmwrite('fig_verif_prof.csv', prof, 'precision', 6);
printf('zonder verdamping: bodem 150 C na %.1f s, 200 C na %.1f s\n', R.t150, R.t200);
% (2) roosterconvergentie met verdamping
for dy = [0.5 0.25 0.125 0.0625]*1e-3
  R = modelC_enthalpie(rho, q, P, 60, dy);
  fprintf(fid,'conv,%g,%.2f,%.2f\n', dy*1e3, R.t150, R.t200);
  printf('met verdamping, dy=%.4f mm: t150=%.2f s t200=%.2f s\n', dy*1e3, R.t150, R.t200);
end
% (3) energiebalans
R = modelC_enthalpie(rho, q, P, 60, 0.125e-3);
Cend = R.s*P.c_vast + R.w_eind*P.c_w;
E_voel = sum(Cend.*(R.T_eind - 100))*R.dy;  E_verd = R.m_verd/P.A_bodem*P.h_fg;
H = R.hist; E_verl = trapz(H(:,1), (H(:,4)-P.T_lucht)/(1/P.h_lucht));
fprintf(fid,'energie,0.125,%.1f,%.1f\n', q*60, E_voel+E_verd+E_verl);
printf('energie: erin %.0f J/m2, terug %.0f J/m2 (verschil %.3f %%)\n', q*60, E_voel+E_verd+E_verl, 100*(E_voel+E_verd+E_verl-q*60)/(q*60));
fclose(fid);
