function R = modelC_enthalpie(rho, q, P, t_eind, dy, t_snap, verdamping)
% MODELC_ENTHALPIE  Rijstlaag na het droogvallen: geleiding + verdamping (enthalpiemethode).
%   rho     rijstdichtheid (g/cm^2, bovenrand)       q       branderflux onder (W/m^2)
%   t_eind  simulatieduur (s)                         dy      celgrootte (m), standaard 0,125 mm
% Per cel: temperatuur T en watergehalte w (kg/m^3). Zolang er water is, kan T niet boven
% 100 C komen: extra energie gaat op aan verdamping (h_fg). Pas als een cel droog is, stijgt T.
% Aannames: damp ontsnapt direct naar boven (de natte laag erboven is 100 C, dus geen condensatie);
% laag krimpt niet; k hangt lineair af van het watergehalte; eindige-volumemethode, expliciet in de tijd.
if nargin < 4, t_eind = 300; end
if nargin < 5 || isempty(dy), dy = 0.125e-3; end
if nargin < 6, t_snap = []; end
if nargin < 7, verdamping = true; end   % false: water blijft, maar verdampt niet (verificatietest)
A  = modelA_balans(rho, modelA_balans(rho,NaN,P).P_ster, P);   % toestand bij droogvallen
L  = A.L_droog;
N  = max(8, round(L/dy)); dy = L/N;  yc = ((1:N)' - 0.5)*dy;   % celmiddens
m_s = A.m_r/(1 + P.vocht0);                       % kg vaste stof
W   = A.m_r - m_s + A.f_droog*A.m_amax;           % kg water in de laag
s   = m_s/(P.A_bodem*L);  w0 = W/(P.A_bodem*L);   % kg/m^3
w = w0*ones(N,1);  T = 100*ones(N,1);
Cvol = @(w) s*P.c_vast + w*P.c_w;                 % J/(m^3 K)
kvan = @(w) P.k_droog + (P.k_nat - P.k_droog)*min(w/w0,1);
amax = max(P.k_nat/Cvol(w0), P.k_droog/Cvol(0));
dt = 0.4*dy^2/amax;  ns = ceil(t_eind/dt);
uit = 1; isnap = 1; SnapT = zeros(N, numel(t_snap)); SnapW = SnapT; ti = 0:0.25:t_eind; H = zeros(numel(ti), 5); m_verd = 0;
for n = 0:ns
  t = n*dt;
  k = kvan(w);
  kf = 2*k(1:end-1).*k(2:end)./(k(1:end-1) + k(2:end));      % harmonisch gemiddelde op celgrens
  F = zeros(N+1,1);                                          % flux omhoog op de celgrenzen
  F(1) = q;                                                  % brander
  F(2:N) = -kf.*(T(2:end) - T(1:end-1))/dy;
  F(N+1) = (T(N) - P.T_lucht)/(1/P.h_lucht + dy/(2*k(N)));   % Robin + halve cel
  dE = dt*(F(1:N) - F(2:N+1))/dy;                            % J/m^3 per stap
  C = Cvol(w);  Tt = T + dE./C;
  nat = verdamping & w > 0 & Tt > 100;
  ov = (Tt(nat) - 100).*C(nat);                              % J/m^3 boven het kookpunt
  dw = min(w(nat), ov/P.h_fg);
  w(nat) = w(nat) - dw;  m_verd = m_verd + sum(dw)*dy*P.A_bodem;
  Tt(nat) = 100 + (ov - dw*P.h_fg)./Cvol(w(nat));
  T = Tt;
  if isnap <= numel(t_snap) && t >= t_snap(isnap)
    SnapT(:,isnap) = T; SnapW(:,isnap) = w/w0; isnap = isnap + 1;
  end
  if uit <= numel(ti) && t >= ti(uit)
    Twand = T(1) + q*dy/(2*k(1));                            % temperatuur tegen het staal
    droog = find(w > 0, 1) - 1; if isempty(droog), droog = N; end
    H(uit,:) = [t, Twand, T(round(N/2)), T(N), droog*dy];
    uit = uit + 1;
  end
end
H = H(1:uit-1,:);
R.rho = rho; R.L = L; R.N = N; R.dy = dy; R.q = q; R.hist = H;  % [t, Twand, Tmidden, Tboven, droge laag (m)]
R.t150 = drempel(H, P.T_socarrat); R.t200 = drempel(H, P.T_verbrand);
R.d150 = interp1(H(:,1), H(:,5), R.t150); R.d200 = interp1(H(:,1), H(:,5), R.t200);
R.w0 = w0; R.C0 = Cvol(w0); R.k0 = kvan(w0); R.s = s; R.m_verd = m_verd; R.T_eind = T; R.w_eind = w; R.yc = yc; R.SnapT = SnapT; R.SnapW = SnapW;
end

function tx = drempel(H, Tx)
  i = find(H(:,2) >= Tx, 1);
  if isempty(i), tx = NaN; elseif i == 1, tx = H(1,1);
  else, tx = interp1(H(i-1:i,2), H(i-1:i,1), Tx); end
end
