P = params_paella();
for rho = P.rho_ref
  R = modelA_balans(rho, 1800, P, 5);
  dlmwrite(sprintf('A_rho%.2f.csv',rho), R.hist, 'precision', 6);
  printf('rho=%.2f bij 1,8 kW: t_droog=%.1f min, gaar %.0f%%\n', rho, R.t_droog/60, 100*R.f_droog);
end
