function P = params_paella()
% PARAMS_PAELLA  Alle invoer voor de paellamodellen A, B en C.
% Elke grootheid: waarde, eenheid, (standaard)onzekerheid of bereik, bron.
% Hugo Paella, Rijstlaag deel 2. Octave/Matlab.

%% Pan (gemeten aan een 50 cm-pan; deel 3 meet opnieuw)
P.D_rand   = 0.50;   % m, bovendiameter (zoals in deel 1)          +/- 0.005 m
P.D_bodem  = 0.45;   % m, bodemdiameter                            +/- 0.005 m
P.A_rand   = pi*P.D_rand^2/4;    % m^2, oppervlak bovenrand (deel 1 gebruikt dit voor rho)
P.A_bodem  = pi*P.D_bodem^2/4;   % m^2, bodemoppervlak (fysica gebruikt dit)

%% Rijst (bomba / D.O. Arroz de Valencia)
P.rho_stort = 800;   % kg/m^3, stortdichtheid droge witte rijst; bereik 773-864 (Kasetsart Univ.)
P.vocht0    = 0.12;  % kg water / kg droge rijst (as-is); bereik 0.11-0.14 (Chuma e.a. 1981)
P.w_abs     = 1.6;   % kg opgenomen water per kg rijst bij gaar; bereik 1.3-1.9
                     % (gekookte witte rijst ~68 % water, USDA FoodData Central; paellarijst iets droger)
P.S_zwel    = 2.5;   % volumezwelfactor laag gaar/rauw; bereik 2-3 (bomba neemt 2-3x volume op)
P.t_gaar    = 17*60; % s, gaartijd bij 100 C (klok 1); bereik 15-18 min (Comunitat Valenciana-recept)
P.x_gaar    = 0.90;  % fractie van de maximale opname die we 'gaar' noemen
P.tau_s     = P.t_gaar/(-log(1-P.x_gaar));   % s, tijdconstante opname (eerste-orde kinetiek)
P.c_rijst   = 1700;  % J/(kg K), droge rijst bij ~12 % vocht (Chuma e.a. 1981)
P.c_vast    = 1500;  % J/(kg K), vaste stof (zetmeel/eiwit), Choi & Okos 1986 (~1.4-1.6 kJ/kgK)

%% Bouillon / water (bij 100 C, Incropera e.a. tabel A.6)
P.r_bouillon = 3.0;  % kg bouillon per kg rijst bij het toevoegen; bereik 2.5-3.5
                     % (Comunitat Valenciana: 1,2 L op 400 g; Rioja: 3 L per kg)
P.c_w   = 4216;      % J/(kg K)
P.k_w   = 0.68;      % W/(m K)
P.rho_w = 958;       % kg/m^3
P.h_fg  = 2.257e6;   % J/kg, verdampingswarmte bij 100 C
P.T_kook = 100;      % C (zeeniveau; zout verhoogt dit < 0.5 C)
P.T_rijst0 = 20;     % C, rijst op kamertemperatuur

%% Thermische eigenschappen van de rijstlaag
P.k_nat   = 0.55;    % W/(m K), gekookte rijst; bereik 0.48-0.70 (Kasetsart Univ.)
P.rhoc_nat= 3.9e6;   % J/(m^3 K), gekookte rijst; bereik 3.18-5.46e6 (Kasetsart Univ.)
P.a_nat   = P.k_nat/P.rhoc_nat;  % m^2/s, ~0.14 mm^2/s (literatuur 0.131-0.158)
P.k_droog = 0.20;    % W/(m K), droge (geroosterde) rijstlaag; ~ rauwe rijst 0.19 (Chuma e.a. 1981)

%% Warmteoverdracht
P.h_lucht = 10;      % W/(m^2 K), vrije convectie bovenkant; bereik 2-25 (Incropera tabel 1.1)
P.T_lucht = 20;      % C

%% Brander (Garcima 40 cm: 11-17 kW bruto max, fabrikant); rendement onbekend -> deel 3
P.P_bruto_max = 13e3;  % W
P.eta         = 0.35;  % rendement, aanname; bereik 0.2-0.5
P.P_netto_max = P.eta*P.P_bruto_max;  % ~4.5 kW netto naar de pan

%% Grenzen voor de bodem (model C)
P.T_socarrat = 150;  % C, Maillard/karamelisatie duidelijk zichtbaar (richtwaarde 140-165)
P.T_verbrand = 200;  % C, verkoling/bitter (richtwaarde 180-220)

%% De vier referentiedichtheden uit deel 1 (g/cm^2 op bovenrand-oppervlak)
P.rho_ref = [0.10 0.25 0.45 0.71];
end
