% SWEEP_C  Socarrat-venster als functie van de branderflux (model C, rho = 0,25).
P = params_paella(); fid = fopen('sweep_C.csv','w'); fprintf(fid,'q_kWm2,t150,t200,venster\n');
for q = [8 10 12 15 18 22 26 30 35]*1e3
  R = modelC_enthalpie(0.25, q, P, 600);
  fprintf(fid,'%g,%.1f,%.1f,%.1f\n', q/1e3, R.t150, R.t200, R.t200-R.t150);
  printf('q=%2d kW/m2: 150C na %6.1f s, 200C na %6.1f s, venster %5.1f s\n', q/1e3, R.t150, R.t200, R.t200-R.t150);
end
fclose(fid);
for rho = P.rho_ref
  R = modelC_enthalpie(rho, P.P_netto_max/P.A_bodem, P, 120);
  dlmwrite(sprintf('C_rho%.2f.csv',rho), R.hist, 'precision', 6);
  printf('rho=%.2f vol vuur: 150C %.1f s, 200C %.1f s\n', rho, R.t150, R.t200);
end
