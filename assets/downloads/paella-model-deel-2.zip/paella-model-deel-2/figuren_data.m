% FIGUREN_DATA  Extra uitvoer voor de figuren in de blog.
P = params_paella(); a = P.a_nat; k = P.k_nat; L = 0.009;
% 2) expliciet Euler: stabiel (r = 0,45, 35 stappen) tegen instabiel (r = 0,55 na 25, 30, 35 stappen)
N = 21; dy = L/(N-1); E = (0:N-1)'*dy*1e3;
dt = 0.45*dy^2/a;
[y,t,T] = heat1d(L, N, a, k, 20, struct('type','D','T',100), struct('type','D','T',60), 35*dt, dt, 'EE', 2); E = [E T(:,end)];
dt = 0.55*dy^2/a;
for ns = [25 30 35]
  [y,t,T] = heat1d(L, N, a, k, 20, struct('type','D','T',100), struct('type','D','T',60), ns*dt, dt, 'EE', 2); E = [E T(:,end)];
end
dlmwrite('fig_EE.csv', E, 'precision', 6);
% 3) model C, fijn rooster: bodemtemperatuur en profielen (rho = 0,25, vol vuur)
q = P.P_netto_max/P.A_bodem; snaps = [0 10 20 30 45 60];
R = modelC_enthalpie(0.25, q, P, 90, 0.0625e-3, snaps);
dlmwrite('fig_C_hist.csv', R.hist, 'precision', 6);
dlmwrite('fig_C_T.csv', [R.yc*1e3 R.SnapT], 'precision', 6);
dlmwrite('fig_C_w.csv', [R.yc*1e3 R.SnapW], 'precision', 6);
printf('C fijn: t150=%.1f t200=%.1f, droog bij 200C %.2f mm\n', R.t150, R.t200, R.d200*1e3);
% 5) sweep venster voor alle dichtheden bij twee fluxen (fijn genoeg)
fid = fopen('fig_venster.csv','w'); fprintf(fid,'rho,q,t150,t200\n');
for rho = P.rho_ref
  for qq = [11.1e3 q]
    R2 = modelC_enthalpie(rho, qq, P, 400);
    fprintf(fid,'%.2f,%g,%.1f,%.1f\n', rho, qq, R2.t150, R2.t200);
  end
end
fclose(fid);
