% MONTECARLO_A  Onzekerheid in het benodigde vermogen P* (model A).
% Elke onzekere invoer wordt uniform getrokken uit zijn bereik (GUM: rechthoekige verdeling).
P0 = params_paella(); rand('seed', 42); Nmc = 2000;
fid = fopen('montecarlo_A.csv','w'); fprintf(fid,'rho,P_mediaan,P_p05,P_p95,frac_haalbaar\n');
for rho = P0.rho_ref
  Ps = zeros(Nmc,1); Pmax = zeros(Nmc,1);
  for i = 1:Nmc
    P = P0;
    P.r_bouillon = 2.5 + rand*1.0;
    P.w_abs      = 1.3 + rand*0.6;
    P.t_gaar     = (15 + rand*3)*60;  P.tau_s = P.t_gaar/(-log(1-P.x_gaar));
    P.c_rijst    = 1600 + rand*200;
    P.D_rand     = 0.495 + rand*0.01; P.A_rand = pi*P.D_rand^2/4;
    eta          = 0.2 + rand*0.3;  Pbr = 11e3 + rand*6e3;
    R = modelA_balans(rho, NaN, P);
    Ps(i) = R.P_ster;  Pmax(i) = eta*Pbr;
  end
  s = sort(Ps);
  fprintf(fid,'%.2f,%.0f,%.0f,%.0f,%.3f\n', rho, median(s), s(round(0.05*Nmc)), s(round(0.95*Nmc)), mean(Ps <= Pmax));
  printf('rho=%.2f P* mediaan %.2f kW (90%%: %.2f-%.2f) | kans dat brander dit haalt: %.0f %%\n', rho, median(s)/1e3, s(round(0.05*Nmc))/1e3, s(round(0.95*Nmc))/1e3, 100*mean(Ps<=Pmax));
end
fclose(fid);
