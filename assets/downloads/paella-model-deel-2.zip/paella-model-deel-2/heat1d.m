function [y, t, T] = heat1d(L, N, a, k, T0, onder, boven, t_eind, dt, schema, n_uit)
% HEAT1D  1D-warmtevergelijking dT/dt = a d2T/dy2 op 0 < y < L (methode der lijnen).
%   Rooster y_j = (j-1)*dy, j = 1..N, dy = L/(N-1)   (zoals in het college)
%   T0     beginwaarde: scalar of vector (N x 1)
%   onder, boven  randvoorwaarde-structs:
%       struct('type','D','T',waarde)              Dirichlet  T = T_rand
%       struct('type','N','q',flux)                Neumann   -k dT/dy = q  (q > 0: warmte de laag in, onder)
%       struct('type','R','h',h,'Tinf',Tinf)       Robin     -k dT/dy = h (T - Tinf)  (boven)
%   schema  'EE' (expliciet Euler), 'IE' (impliciet Euler), 'TR' (trapezium / Crank-Nicolson)
%   n_uit   aantal opgeslagen tijdstippen
% Het semi-discrete stelsel is dT/dt = A*T + b; per stap:
%   EE: T+ = (I + dt A) T + dt b
%   IE: (I - dt A) T+ = T + dt b
%   TR: (I - dt/2 A) T+ = (I + dt/2 A) T + dt b
if nargin < 11, n_uit = 200; end
dy = L/(N-1); y = (0:N-1)'*dy;
e = ones(N,1);
A = spdiags([e -2*e e], -1:1, N, N);
b = zeros(N,1);
% --- onderrand (j = 1) ---
switch onder.type
  case 'D'
    A(1,:) = 0;                      % T_1 ligt vast
  case 'N'                           % spookpunt T_0 = T_2 + 2 dy q/k
    A(1,2) = 2;  b(1) = 2*dy*onder.q/k;
  case 'R'                           % -k dT/dy = h (Tinf - T) aan de onderkant
    A(1,2) = 2;  A(1,1) = -2*(1 + dy*onder.h/k);  b(1) = 2*dy*onder.h/k*onder.Tinf;
end
% --- bovenrand (j = N) ---
switch boven.type
  case 'D'
    A(N,:) = 0;
  case 'N'                           % -k dT/dy = q (q > 0: warmte de laag uit)
    A(N,N-1) = 2;  b(N) = -2*dy*boven.q/k;
  case 'R'                           % spookpunt T_{N+1} = T_{N-1} - 2 dy h/k (T_N - Tinf)
    A(N,N-1) = 2;  A(N,N) = -2*(1 + dy*boven.h/k);  b(N) = 2*dy*boven.h/k*boven.Tinf;
end
A = (a/dy^2)*A;  b = (a/dy^2)*b;

if isscalar(T0), T = T0*e; else, T = T0(:); end
if strcmp(onder.type,'D'), T(1) = onder.T; end
if strcmp(boven.type,'D'), T(N) = boven.T; end

ns = round(t_eind/dt);
I = speye(N);
switch schema
  case 'IE', M = I - dt*A;
  case 'TR', M = I - dt/2*A;  Mr = I + dt/2*A;
end
if any(strcmp(schema, {'IE','TR'})), [Lf, Uf, Pf, Qf] = lu(M); end
iuit = unique(round(linspace(0, ns, n_uit)));
t = iuit'*dt; Tout = zeros(N, numel(iuit)); k_uit = 1;
if iuit(1) == 0, Tout(:,1) = T; k_uit = 2; end
for n = 1:ns
  switch schema
    case 'EE', T = T + dt*(A*T + b);
    case 'IE', T = Qf*(Uf\(Lf\(Pf*(T + dt*b))));
    case 'TR', T = Qf*(Uf\(Lf\(Pf*(Mr*T + dt*b))));
  end
  if k_uit <= numel(iuit) && n == iuit(k_uit)
    Tout(:,k_uit) = T; k_uit = k_uit + 1;
  end
end
T = Tout;
end
