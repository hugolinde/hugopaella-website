% RUN_ALLES  Draait alle berekeningen voor Rijstlaag deel 2. Octave 6+ of Matlab.
hist_A          % fase 1: verloop van de vrije bouillon bij 1,8 kW netto
montecarlo_A    % fase 1: onzekerheid in het benodigde vermogen
verificatie_C   % fase 2: exacte oplossing (zonder verdamping), convergentie, energiebalans
sweep_C         % fase 2: socarrat-venster als functie van het vuur
figuren_data    % extra uitvoer voor de figuren (stabiliteit, droogfront)
