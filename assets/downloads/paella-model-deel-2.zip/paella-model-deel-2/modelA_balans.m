function R = modelA_balans(rho, P_netto, P, dt)
% MODELA_BALANS  Water- en energiebalans van de hele pan (0D, alleen tijd).
%   rho      rijstdichtheid in g/cm^2 (op bovenrand-oppervlak, zoals deel 1)
%   P_netto  netto vermogen naar de paella in W (scalar of functiehandle @(t))
%   P        parameters (params_paella)
% Klok 1: de korrel neemt water op, m_a(t) = m_amax (1 - exp(-t/tau_s)).
% Klok 2: het vrije vocht verdwijnt door opname en verdamping.
%   dm_l/dt = -dm_a/dt - P_netto/h_fg      (zodra alles weer 100 C is)
% Uitkomst: t_droog (vocht op), t_gaar, Pi = t_droog/t_gaar, laagdikte L(t).
if nargin < 4, dt = 1; end


m_r   = rho*10 * P.A_rand;          % kg rijst (g/cm^2 -> kg/m^2 is x10)
m_b   = P.r_bouillon * m_r;         % kg bouillon bij toevoegen rijst
m_amax= P.w_abs * m_r;              % kg water dat de korrel maximaal opneemt

% Mengtemperatuur na toevoegen koude rijst (energiebalans)
T_mix = (m_b*P.c_w*P.T_kook + m_r*P.c_rijst*P.T_rijst0)/(m_b*P.c_w + m_r*P.c_rijst);
Q_op  = (m_b*P.c_w + m_r*P.c_rijst)*(P.T_kook - T_mix);   % J om weer te koken

L0 = m_r/(P.rho_stort*P.A_bodem);   % m, rauwe laag op de bodem
% Vermogen waarbij de klokken gelijk lopen (droog precies op t_gaar), exact:
P_ster = (P.h_fg*(m_b - P.x_gaar*m_amax) + Q_op)/P.t_gaar;
if isempty(P_netto) || (isnumeric(P_netto) && isnan(P_netto))
  R.P_ster = P_ster; R.q_ster = P_ster/P.A_bodem; return;   % snelle modus
end

if ~isa(P_netto, 'function_handle'), Pc = P_netto; P_netto = @(t) Pc; end
t = 0; m_a = 0; m_ev = 0; Q = 0; kookt = false;
N = ceil(60*60/dt); out = zeros(N,5); n = 0; t_droog = NaN; t_kook = NaN;
while t < 60*60
  n = n + 1;
  m_l = m_b - m_a - m_ev;
  f   = m_a/m_amax;
  L   = L0*(1 + (P.S_zwel-1)*f);
  out(n,:) = [t, m_l, m_a, m_ev, L];
  if m_l <= 0, t_droog = t; break; end
  Pn = P_netto(t);
  if ~kookt
    Q = Q + Pn*dt;
    if Q >= Q_op, kookt = true; t_kook = t; end
    dm_ev = 0;
  else
    dm_ev = Pn*dt/P.h_fg;
  end
  dm_a = (m_amax - m_a)*(1 - exp(-dt/P.tau_s));   % exacte stap eerste-orde opname
  m_a = m_a + dm_a; m_ev = m_ev + dm_ev; t = t + dt;
end
out = out(1:n,:);

R.rho = rho; R.m_r = m_r; R.m_b = m_b; R.m_amax = m_amax;
R.T_mix = T_mix; R.Q_op = Q_op; R.t_kook = t_kook;
R.t_droog = t_droog; R.t_gaar = P.t_gaar; R.Pi = t_droog/P.t_gaar;
R.L0 = L0; R.L_droog = out(end,5); R.f_droog = out(end,3)/m_amax;
R.hist = out;   % [t, m_vrij, m_opgenomen, m_verdampt, L]
% Vermogen waarbij de klokken gelijk lopen (droog precies op t_gaar):
R.P_ster = P_ster;
R.q_ster = R.P_ster/P.A_bodem;     % W/m^2
end
